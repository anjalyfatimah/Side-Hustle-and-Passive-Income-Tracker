package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// Tipe enum untuk kategori side hustle
type KategoriSideHustle string

const (
	PekerjaanSampingan KategoriSideHustle = "Pekerjaan Sampingan"
	Freelancing        KategoriSideHustle = "Freelancing"
	BisnisDigital      KategoriSideHustle = "Bisnis Digital"
	InvestasiPasif     KategoriSideHustle = "Investasi Pasif"
)

// Struktur untuk data side hustle
type SideHustle struct {
	ID             int
	Nama           string
	Kategori       KategoriSideHustle
	MinPenghasilan float64
	MaxPenghasilan float64
	BiayaAwal      float64
	WaktuPerMinggu int
	Keterampilan   []string
	Deskripsi      string
}

// Struktur untuk data pendapatan
type SumberPendapatan struct {
	Nama        string
	Penghasilan float64
}

// Struktur untuk data biaya operasional
type BiayaOperasional struct {
	Nama  string
	Biaya float64
}

// Database side hustle yang sudah disediakan
func GetSideHustleDatabase() []SideHustle {
	return []SideHustle{
		{
			ID:             1,
			Nama:           "Mengajar Les Privat",
			Kategori:       PekerjaanSampingan,
			MinPenghasilan: 1000000,
			MaxPenghasilan: 4000000,
			BiayaAwal:      500000,
			WaktuPerMinggu: 8,
			Keterampilan:   []string{"Mengajar", "Komunikasi", "Kesabaran"},
			Deskripsi:      "Memberikan les privat untuk siswa SD, SMP, atau SMA dalam mata pelajaran tertentu",
		},
		{
			ID:             2,
			Nama:           "Freelance Writer",
			Kategori:       Freelancing,
			MinPenghasilan: 3000000,
			MaxPenghasilan: 8000000,
			BiayaAwal:      1000000,
			WaktuPerMinggu: 15,
			Keterampilan:   []string{"Menulis", "Riset", "SEO"},
			Deskripsi:      "Menulis artikel, blog, atau konten untuk klien di berbagai platform freelance",
		},
		{
			ID:             3,
			Nama:           "Desain Grafis Freelance",
			Kategori:       Freelancing,
			MinPenghasilan: 2500000,
			MaxPenghasilan: 10000000,
			BiayaAwal:      3000000,
			WaktuPerMinggu: 12,
			Keterampilan:   []string{"Photoshop", "Illustrator", "Kreativitas"},
			Deskripsi:      "Membuat desain logo, poster, brosur dan materi visual lainnya untuk klien",
		},
		{
			ID:             4,
			Nama:           "Toko Online",
			Kategori:       BisnisDigital,
			MinPenghasilan: 2000000,
			MaxPenghasilan: 15000000,
			BiayaAwal:      5000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"Pemasaran", "Manajemen Persediaan", "Layanan Pelanggan"},
			Deskripsi:      "Menjual produk secara online melalui marketplace atau website sendiri",
		},
		{
			ID:             5,
			Nama:           "Dropshipping",
			Kategori:       BisnisDigital,
			MinPenghasilan: 1500000,
			MaxPenghasilan: 10000000,
			BiayaAwal:      2000000,
			WaktuPerMinggu: 15,
			Keterampilan:   []string{"Pemasaran Digital", "Pemilihan Produk", "Analisis Pasar"},
			Deskripsi:      "Menjual produk tanpa menyimpan stok, dengan mengirim langsung dari supplier ke pelanggan",
		},
		{
			ID:             6,
			Nama:           "Investasi Reksa Dana",
			Kategori:       InvestasiPasif,
			MinPenghasilan: 500000,
			MaxPenghasilan: 2000000,
			BiayaAwal:      5000000,
			WaktuPerMinggu: 2,
			Keterampilan:   []string{"Analisis Keuangan", "Manajemen Risiko"},
			Deskripsi:      "Investasi pada instrumen reksa dana untuk mendapatkan return jangka panjang",
		},
		{
			ID:             7,
			Nama:           "Saham Dividen",
			Kategori:       InvestasiPasif,
			MinPenghasilan: 1000000,
			MaxPenghasilan: 5000000,
			BiayaAwal:      10000000,
			WaktuPerMinggu: 3,
			Keterampilan:   []string{"Analisis Fundamental", "Kesabaran", "Riset"},
			Deskripsi:      "Investasi pada saham yang membagikan dividen secara rutin",
		},
		{
			ID:             8,
			Nama:           "YouTube Creator",
			Kategori:       BisnisDigital,
			MinPenghasilan: 1000000,
			MaxPenghasilan: 20000000,
			BiayaAwal:      3000000,
			WaktuPerMinggu: 15,
			Keterampilan:   []string{"Editing Video", "Public Speaking", "SEO"},
			Deskripsi:      "Membuat konten video di YouTube dan mendapatkan penghasilan dari iklan dan sponsor",
		},
		{
			ID:             9,
			Nama:           "Ojek Online",
			Kategori:       PekerjaanSampingan,
			MinPenghasilan: 1500000,
			MaxPenghasilan: 4000000,
			BiayaAwal:      2000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"Mengemudi", "Navigasi", "Layanan Pelanggan"},
			Deskripsi:      "Menjadi pengemudi ojek online di waktu luang",
		},
		{
			ID:             10,
			Nama:           "Food Delivery",
			Kategori:       PekerjaanSampingan,
			MinPenghasilan: 1000000,
			MaxPenghasilan: 3500000,
			BiayaAwal:      1500000,
			WaktuPerMinggu: 16,
			Keterampilan:   []string{"Mengemudi", "Manajemen Waktu", "Ketelitian"},
			Deskripsi:      "Mengantar makanan melalui aplikasi delivery",
		},
		{
			ID:             11,
			Nama:           "Freelance Web Developer",
			Kategori:       Freelancing,
			MinPenghasilan: 5000000,
			MaxPenghasilan: 15000000,
			BiayaAwal:      2000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"HTML/CSS", "JavaScript", "PHP/Python"},
			Deskripsi:      "Membuat dan mengembangkan website untuk klien",
		},
		{
			ID:             12,
			Nama:           "Freelance Mobile App Developer",
			Kategori:       Freelancing,
			MinPenghasilan: 6000000,
			MaxPenghasilan: 18000000,
			BiayaAwal:      3000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"Java/Kotlin", "Swift", "React Native"},
			Deskripsi:      "Membuat aplikasi mobile untuk Android atau iOS",
		},
		{
			ID:             13,
			Nama:           "Sewa Properti",
			Kategori:       InvestasiPasif,
			MinPenghasilan: 3000000,
			MaxPenghasilan: 10000000,
			BiayaAwal:      200000000,
			WaktuPerMinggu: 5,
			Keterampilan:   []string{"Manajemen Properti", "Negosiasi", "Perawatan"},
			Deskripsi:      "Menyewakan rumah, apartemen, atau ruang komersial",
		},
		{
			ID:             14,
			Nama:           "Affiliate Marketing",
			Kategori:       BisnisDigital,
			MinPenghasilan: 1000000,
			MaxPenghasilan: 8000000,
			BiayaAwal:      1000000,
			WaktuPerMinggu: 12,
			Keterampilan:   []string{"Pemasaran Digital", "SEO", "Copywriting"},
			Deskripsi:      "Mempromosikan produk orang lain dan mendapatkan komisi dari setiap penjualan",
		},
		{
			ID:             15,
			Nama:           "Fotografi",
			Kategori:       Freelancing,
			MinPenghasilan: 2000000,
			MaxPenghasilan: 10000000,
			BiayaAwal:      10000000,
			WaktuPerMinggu: 10,
			Keterampilan:   []string{"Fotografi", "Editing Foto", "Komunikasi"},
			Deskripsi:      "Menjadi fotografer untuk acara, potret, produk, dll",
		},
		{
			ID:             16,
			Nama:           "Print on Demand",
			Kategori:       BisnisDigital,
			MinPenghasilan: 1500000,
			MaxPenghasilan: 7000000,
			BiayaAwal:      1000000,
			WaktuPerMinggu: 10,
			Keterampilan:   []string{"Desain", "Pemasaran", "Branding"},
			Deskripsi:      "Menjual produk dengan desain kustom yang dicetak sesuai pesanan",
		},
		{
			ID:             17,
			Nama:           "Transcriber",
			Kategori:       Freelancing,
			MinPenghasilan: 1500000,
			MaxPenghasilan: 5000000,
			BiayaAwal:      500000,
			WaktuPerMinggu: 15,
			Keterampilan:   []string{"Mendengarkan", "Mengetik Cepat", "Bahasa"},
			Deskripsi:      "Mentranskripsi rekaman audio menjadi teks tertulis",
		},
		{
			ID:             18,
			Nama:           "Course Creator",
			Kategori:       BisnisDigital,
			MinPenghasilan: 2000000,
			MaxPenghasilan: 15000000,
			BiayaAwal:      2000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"Mengajar", "Produksi Video", "Pemasaran"},
			Deskripsi:      "Membuat dan menjual kursus online di platform seperti Udemy atau Skillshare",
		},
		{
			ID:             19,
			Nama:           "P2P Lending",
			Kategori:       InvestasiPasif,
			MinPenghasilan: 500000,
			MaxPenghasilan: 3000000,
			BiayaAwal:      10000000,
			WaktuPerMinggu: 2,
			Keterampilan:   []string{"Analisis Kredit", "Manajemen Risiko"},
			Deskripsi:      "Meminjamkan uang melalui platform peer-to-peer lending",
		},
		{
			ID:             20,
			Nama:           "Virtual Assistant",
			Kategori:       Freelancing,
			MinPenghasilan: 2500000,
			MaxPenghasilan: 8000000,
			BiayaAwal:      1000000,
			WaktuPerMinggu: 20,
			Keterampilan:   []string{"Administrasi", "Manajemen Waktu", "Teknologi"},
			Deskripsi:      "Memberikan bantuan administratif secara jarak jauh kepada klien",
		},
	}
}

// Fungsi untuk menampilkan detail side hustle
func TampilkanDetailSideHustle(sh SideHustle) {
	fmt.Println("\n=== DETAIL SIDE HUSTLE ===")
	fmt.Printf("ID               : %d\n", sh.ID)
	fmt.Printf("Nama             : %s\n", sh.Nama)
	fmt.Printf("Kategori         : %s\n", sh.Kategori)
	fmt.Printf("Estimasi Penghasilan: Rp %.0f - Rp %.0f per bulan\n", sh.MinPenghasilan, sh.MaxPenghasilan)
	fmt.Printf("Biaya Awal       : Rp %.0f\n", sh.BiayaAwal)
	fmt.Printf("Waktu yang Dibutuhkan: %d jam per minggu\n", sh.WaktuPerMinggu)
	fmt.Printf("Keterampilan yang Dibutuhkan: %s\n", strings.Join(sh.Keterampilan, ", "))
	fmt.Printf("Deskripsi        : %s\n", sh.Deskripsi)
}

// Fungsi untuk pencarian side hustle dengan berbagai filter
func CariSideHustle(database []SideHustle, namaKunci string, kategori KategoriSideHustle, minPenghasilan, maxPenghasilan float64, maxWaktu int, maxBiaya float64, keterampilanKunci string) []SideHustle {
	var hasil []SideHustle

	for _, sh := range database {
		// Filter berdasarkan nama jika ada kata kunci nama
		if namaKunci != "" && !strings.Contains(strings.ToLower(sh.Nama), strings.ToLower(namaKunci)) {
			continue
		}

		// Filter berdasarkan kategori jika kategori dipilih
		if kategori != "" && sh.Kategori != kategori {
			continue
		}

		// Filter berdasarkan range penghasilan jika ada range
		if minPenghasilan > 0 && sh.MaxPenghasilan < minPenghasilan {
			continue
		}
		if maxPenghasilan > 0 && sh.MinPenghasilan > maxPenghasilan {
			continue
		}

		// Filter berdasarkan waktu jika ada batasan waktu
		if maxWaktu > 0 && sh.WaktuPerMinggu > maxWaktu {
			continue
		}

		// Filter berdasarkan biaya awal jika ada batasan biaya
		if maxBiaya > 0 && sh.BiayaAwal > maxBiaya {
			continue
		}

		// Filter berdasarkan keterampilan jika ada kata kunci keterampilan
		if keterampilanKunci != "" {
			keterampilanDitemukan := false
			for _, k := range sh.Keterampilan {
				if strings.Contains(strings.ToLower(k), strings.ToLower(keterampilanKunci)) {
					keterampilanDitemukan = true
					break
				}
			}
			if !keterampilanDitemukan {
				continue
			}
		}

		// Jika semua filter terpenuhi, tambahkan ke hasil
		hasil = append(hasil, sh)
	}

	return hasil
}

// Fungsi untuk menampilkan hasil pencarian
func TampilkanHasilPencarian(hasil []SideHustle) {
	if len(hasil) == 0 {
		fmt.Println("Tidak ditemukan side hustle yang sesuai dengan kriteria pencarian")
		return
	}

	fmt.Println("\n=== HASIL PENCARIAN ===")
	fmt.Printf("%-3s %-25s %-20s %-25s %-15s %-15s\n", "ID", "Nama", "Kategori", "Penghasilan/Bulan", "Modal Awal", "Waktu/Minggu")
	fmt.Println("-----------------------------------------------------------------------------------------------------")

	for _, sh := range hasil {
		fmt.Printf("%-3d %-25s %-20s Rp %.0f - Rp %.0f %-15.0f %-3d jam\n",
			sh.ID, sh.Nama, sh.Kategori,
			sh.MinPenghasilan, sh.MaxPenghasilan, sh.BiayaAwal, sh.WaktuPerMinggu)
	}
}

// Fungsi untuk input sumber pendapatan
func InputSumberPendapatan() []SumberPendapatan {
	var sumberPendapatan []SumberPendapatan
	scanner := bufio.NewScanner(os.Stdin)

	fmt.Println("\n=== INPUT SUMBER PENDAPATAN ===")
	for {
		var sumber SumberPendapatan

		fmt.Print("Nama sumber pendapatan (kosongkan untuk selesai): ")
		scanner.Scan()
		sumber.Nama = scanner.Text()

		if sumber.Nama == "" {
			break
		}

		fmt.Print("Jumlah penghasilan (Rp): ")
		scanner.Scan()
		penghasilanStr := scanner.Text()
		penghasilan, err := strconv.ParseFloat(penghasilanStr, 64)
		if err != nil {
			fmt.Println("Input tidak valid, silakan coba lagi")
			continue
		}
		sumber.Penghasilan = penghasilan

		sumberPendapatan = append(sumberPendapatan, sumber)
	}

	return sumberPendapatan
}

// Fungsi untuk input biaya operasional
func InputBiayaOperasional() []BiayaOperasional {
	var biayaOperasional []BiayaOperasional
	scanner := bufio.NewScanner(os.Stdin)

	fmt.Println("\n=== INPUT BIAYA OPERASIONAL ===")
	for {
		var biaya BiayaOperasional

		fmt.Print("Nama biaya (kosongkan untuk selesai): ")
		scanner.Scan()
		biaya.Nama = scanner.Text()

		if biaya.Nama == "" {
			break
		}

		fmt.Print("Jumlah biaya (Rp): ")
		scanner.Scan()
		biayaStr := scanner.Text()
		jumlahBiaya, err := strconv.ParseFloat(biayaStr, 64)
		if err != nil {
			fmt.Println("Input tidak valid, silakan coba lagi")
			continue
		}
		biaya.Biaya = jumlahBiaya

		biayaOperasional = append(biayaOperasional, biaya)
	}

	return biayaOperasional
}

// Fungsi untuk menghitung total penghasilan dan keuntungan
func HitungPenghasilanDanKeuntungan(sumberPendapatan []SumberPendapatan, biayaOperasional []BiayaOperasional) {
	var totalPendapatan float64
	var totalBiaya float64

	fmt.Println("\n=== RINGKASAN KEUANGAN ===")

	// Tampilkan dan hitung total pendapatan
	fmt.Println("\nSUMBER PENDAPATAN:")
	fmt.Printf("%-30s %-15s\n", "Nama", "Jumlah (Rp)")
	fmt.Println("---------------------------------------")
	for _, pendapatan := range sumberPendapatan {
		fmt.Printf("%-30s Rp %-15.0f\n", pendapatan.Nama, pendapatan.Penghasilan)
		totalPendapatan += pendapatan.Penghasilan
	}
	fmt.Println("---------------------------------------")
	fmt.Printf("%-30s Rp %-15.0f\n", "TOTAL PENDAPATAN", totalPendapatan)

	// Tampilkan dan hitung total biaya
	fmt.Println("\nBIAYA OPERASIONAL:")
	fmt.Printf("%-30s %-15s\n", "Nama", "Jumlah (Rp)")
	fmt.Println("---------------------------------------")
	for _, biaya := range biayaOperasional {
		fmt.Printf("%-30s Rp %-15.0f\n", biaya.Nama, biaya.Biaya)
		totalBiaya += biaya.Biaya
	}
	fmt.Println("---------------------------------------")
	fmt.Printf("%-30s Rp %-15.0f\n", "TOTAL BIAYA", totalBiaya)

	// Hitung dan tampilkan keuntungan/kerugian
	keuntungan := totalPendapatan - totalBiaya
	fmt.Println("\n---------------------------------------")
	fmt.Printf("%-30s Rp %-15.0f\n", "KEUNTUNGAN/KERUGIAN", keuntungan)

	if keuntungan > 0 {
		fmt.Println("\nStatus: UNTUNG")
		fmt.Printf("Margin keuntungan: %.2f%%\n", (keuntungan/totalPendapatan)*100)
	} else if keuntungan < 0 {
		fmt.Println("\nStatus: RUGI")
		fmt.Printf("Margin kerugian: %.2f%%\n", (keuntungan/totalPendapatan)*-100)
	} else {
		fmt.Println("\nStatus: IMPAS (Break Even)")
	}
}

func main() {
	database := GetSideHustleDatabase()
	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Println("\n===== PENCARI SIDE HUSTLE =====")
		fmt.Println("1. Tampilkan Semua Side Hustle")
		fmt.Println("2. Cari Side Hustle (Filter Lanjutan)")
		fmt.Println("3. Lihat Detail Side Hustle")
		fmt.Println("4. Kalkulator Penghasilan dan Keuntungan")
		fmt.Println("0. Keluar")
		fmt.Print("\nPilih menu: ")

		scanner.Scan()
		pilihan := scanner.Text()

		switch pilihan {
		case "1":
			// Tampilkan semua side hustle
			TampilkanHasilPencarian(database)

		case "2":
			// Cari side hustle dengan filter lanjutan
			var namaKunci string
			var kategori KategoriSideHustle
			var minPenghasilan, maxPenghasilan, maxBiaya float64
			var maxWaktu int
			var keterampilanKunci string

			fmt.Println("\n=== PENCARIAN DENGAN FILTER LANJUTAN ===")
			fmt.Println("(Kosongkan input untuk mengabaikan filter)")

			// Input filter nama
			fmt.Print("Kata kunci nama: ")
			scanner.Scan()
			namaKunci = scanner.Text()

			// Input filter kategori
			fmt.Println("\nPilih kategori:")
			fmt.Println("1. Pekerjaan Sampingan")
			fmt.Println("2. Freelancing")
			fmt.Println("3. Bisnis Digital")
			fmt.Println("4. Investasi Pasif")
			fmt.Println("0. Semua Kategori")
			fmt.Print("Masukkan pilihan kategori (0-4): ")
			scanner.Scan()
			kategoriPilihan := scanner.Text()

			switch kategoriPilihan {
			case "1":
				kategori = PekerjaanSampingan
			case "2":
				kategori = Freelancing
			case "3":
				kategori = BisnisDigital
			case "4":
				kategori = InvestasiPasif
			default:
				kategori = ""
			}

			// Input filter range penghasilan
			fmt.Print("Penghasilan minimal per bulan (Rp): ")
			scanner.Scan()
			minStr := scanner.Text()
			if minStr != "" {
				min, err := strconv.ParseFloat(minStr, 64)
				if err == nil {
					minPenghasilan = min
				}
			}

			fmt.Print("Penghasilan maksimal per bulan (Rp): ")
			scanner.Scan()
			maxStr := scanner.Text()
			if maxStr != "" {
				max, err := strconv.ParseFloat(maxStr, 64)
				if err == nil {
					maxPenghasilan = max
				}
			}

			// Input filter waktu
			fmt.Print("Waktu maksimal yang tersedia per minggu (jam): ")
			scanner.Scan()
			waktuStr := scanner.Text()
			if waktuStr != "" {
				waktu, err := strconv.Atoi(waktuStr)
				if err == nil {
					maxWaktu = waktu
				}
			}

			// Input filter biaya awal
			fmt.Print("Modal maksimal yang tersedia (Rp): ")
			scanner.Scan()
			biayaStr := scanner.Text()
			if biayaStr != "" {
				biaya, err := strconv.ParseFloat(biayaStr, 64)
				if err == nil {
					maxBiaya = biaya
				}
			}

			// Input filter keterampilan
			fmt.Print("Keterampilan yang dimiliki: ")
			scanner.Scan()
			keterampilanKunci = scanner.Text()

			// Lakukan pencarian
			hasil := CariSideHustle(database, namaKunci, kategori, minPenghasilan, maxPenghasilan, maxWaktu, maxBiaya, keterampilanKunci)

			// Tampilkan hasil
			TampilkanHasilPencarian(hasil)

		case "3":
			// Lihat detail side hustle
			fmt.Print("Masukkan ID side hustle yang ingin dilihat detailnya: ")
			scanner.Scan()
			idStr := scanner.Text()
			id, err := strconv.Atoi(idStr)
			if err != nil {
				fmt.Println("Input tidak valid")
				continue
			}

			ditemukan := false
			for _, sh := range database {
				if sh.ID == id {
					TampilkanDetailSideHustle(sh)
					ditemukan = true
					break
				}
			}

			if !ditemukan {
				fmt.Println("Side hustle dengan ID tersebut tidak ditemukan")
			}

		case "4":
			// Kalkulator penghasilan dan keuntungan
			sumberPendapatan := InputSumberPendapatan()
			biayaOperasional := InputBiayaOperasional()
			HitungPenghasilanDanKeuntungan(sumberPendapatan, biayaOperasional)

		case "0":
			fmt.Println("Terima kasih telah menggunakan Pencari Side Hustle!")
			return

		default:
			fmt.Println("Pilihan tidak valid")
		}
	}
}
